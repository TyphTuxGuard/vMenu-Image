# vMenu-Custom-Image

vMenu-YTD
This is the YTD you can use to replace your banner on your vMenu! vMenu was not made by me and I only am posting this to help people when it comes to adding something custom to their server!

► How to setup and configure? ◄

You will need the program (OPENIV)
With OPENIV you will need to locate the colored menu in this YTD
Then you want to customize it yourself
Lastly you need to put it in a stream folder with a resource.lua outside of the stream folder and start up your server with the ytd started!
► Resources ◄

⚡ Video Tutorial https://youtu.be/-iLByXz0tNI

⚡ Support Discord https://discord.gg/s499CRMJhp

⚡ OPEN IV (Editing) https://openiv.com/

⚡ Photoea https://www.photopea.com/
